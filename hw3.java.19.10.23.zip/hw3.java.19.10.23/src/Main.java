import days_of_week.Day;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("Введите текущий день недели");
        Scanner scr = new Scanner(System.in);
        Day userDay = Day.valueOf(scr.nextLine());
        for (Day s : Day.values()) {
            System.out.println( s == userDay ? "" : s);
        }
    }
}
/*Используйте foreach.
Дан Enum дней недели. Пользователь вводит имя текущего дня в консоль.
Программа должна вывести все дни недели, кроме данного.*/
