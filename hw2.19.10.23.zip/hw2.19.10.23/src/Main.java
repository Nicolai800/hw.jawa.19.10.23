import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);
        do{
            System.out.println("Введите первое число диапазона ");
            int n1 = scr.nextInt();
            System.out.println("Введите второе число диапазона");
            int n2 = scr.nextInt();
            int min = Integer.min(n1,n2);
            int max = Integer.max(n1,n2);
            int summ = 0;
            for (int i = min; i <= max; i++) {
                if (i % 2 != 0){
                    summ = summ +i;
                }
            }
            System.out.println(summ);
            System.out.println("Введите quit для выхода");

        } while (!"quit".equalsIgnoreCase(scr.nextLine())); // Работает не корректно,

    }
}

/*Используйте for для вычисления суммы.
Используйте do-while для организации повторения программы.
Необходимо суммировать все нечётные целые числа в диапазоне, введённом пользователем.
Программу повторять, пока пользователь не введёт «quit».*/